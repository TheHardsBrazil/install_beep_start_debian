#!/bin/bash

# Script de instalação do pacote beepstart_linux_amd64.deb

DEB_FILE="beepstart_linux_amd64.deb"

echo "Instalando o pacote ${DEB_FILE}..."
sudo dpkg -i $DEB_FILE

echo "Resolvendo dependências..."
sudo apt-get install -f -y

if [ $? -eq 0 ]; then
    echo "Instalação do ${DEB_FILE} concluída com sucesso."
else
    echo "Erro na instalação do ${DEB_FILE}. Verifique os logs."
    exit 1
fi
